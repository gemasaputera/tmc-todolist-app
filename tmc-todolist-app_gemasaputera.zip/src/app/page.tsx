import MainPage from '@/fragments/todolist/MainPage';

const Home = async () => {
  return <MainPage />;
};

export default Home;
