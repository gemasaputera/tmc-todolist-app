export type UserData = {
  email: string;
  password?: string;
  name?: string;
  image?: string;
};
